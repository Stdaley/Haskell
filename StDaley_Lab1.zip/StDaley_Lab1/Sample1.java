import java.io.*;

public class Sample1 {
  public static void main (String[] argv)  {
    System.out.println("Hello, World!");
  }
}