// There are five syntax errors in this little
// program.  To start you out finding and fixing
// them, there is a missing " on line 9.

import java.io.*;                      

public class Bugs1{
  public static void main(String[]argv) {
    System.out.println("Hello, World!");
}
} // Added to remove the end of parsing error.

// Added a " to the beginning of Hello to complete the string call
// Added an "s" to the class name as it was entered as "Bug" but the file name is "Bugs"
// Added a semicolon to the end of the system out print.